The content of this wiki will be included in a forthcoming book from Chapman
& Hall, and hence I need to own the copyright for the complete content
of the wiki. I will make some money from the book, but it's not likely to be a 
huge amount (probably <$10,000 over 2 years, which works out to a fairly low 
hourly rate). The wiki will continue to be freely available and I'll acknowledge
all contributions in the printed book.

To confirm that you're ok with giving me your copyright, please include the 
phrase: "I assign the copyright of this contribution to Hadley Wickham".

If you have any questions, feel free to raise them in the pull request, or 
send me [an email](mailto:h.wickham@gmail.com).