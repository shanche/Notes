#ifndef INCLUDED_MATRIX_H
#define INCLUDED_MATRIX_H
#include<iostream>
#include<vector>

namespace NMethod
{
	typedef double ValueType;
	class Matrix
	{
	private:
		std::vector<std::vector<ValueType> > d_data;
		int d_rows;
		int d_cols;
	public:
		//constructor
		Matrix();
		Matrix(int row, int column);
		Matrix(ValueType * data, int row, int column);
		
		//return a diagonal matrix with diagonal value data
		static Matrix diag(ValueType * data, int length);
		static Matrix ones(int row, int column);
		static Matrix indentity(int length);
		Matrix(const Matrix& rhs);
		Matrix& operator=(const Matrix& rhs);

		//operator overloading
		std::vector<ValueType>& operator[](int row);
		const std::vector<ValueType>& operator[](int row) const;
		//std::vector<ValueType> operator[](int row) const;
		Matrix operator+(const Matrix& b) const;
		Matrix operator-(const Matrix& b) const;
		Matrix operator*(const Matrix& b) const;

		//getters
		int rows()const{return d_rows;}
		int cols()const{return d_cols;}

		//utils
		void print() const;
	};
}
#endif