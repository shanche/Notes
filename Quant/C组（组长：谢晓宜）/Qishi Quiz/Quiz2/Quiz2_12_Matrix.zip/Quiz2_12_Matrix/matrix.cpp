#include "matrix.h"
#include <iostream>
#include <exception>
#include <iomanip>

namespace NMethod
{
	Matrix::Matrix(){}

	Matrix::Matrix(int row, int column)
		:d_rows(row),d_cols(column)
	{
		if(row < 0 || column < 0)
			throw std::invalid_argument("Matrix rows and columns should be positive");
		d_data.resize(row);
        for(int i = 0; i < row; ++i)
			d_data[i].resize(column, 0);
	}
	Matrix::Matrix(ValueType * data, int row, int column)
		:d_rows(row),d_cols(column)
	{
		if(row < 0 || column < 0)
			throw std::invalid_argument("Matrix rows and columns should be positive");
		if(data == NULL)
			throw std::invalid_argument("data is NULL");
		d_data.resize(row);
		for(int i = 0; i < row; ++i)
			for(int j = 0; j < column; ++j)
				d_data[i].push_back(data[i * column + j]);
	}

	Matrix::Matrix(const Matrix& rhs)
	{
		d_rows = rhs.rows();
		d_cols = rhs.cols();
		d_data.resize(rhs.rows());
		for(int i = 0; i < rhs.rows(); ++i)
			for(int j = 0; j < rhs.cols(); ++j)
				d_data[i].push_back(rhs[i][j]);
	}

	Matrix& Matrix::operator=(const Matrix& rhs)
	{
		if(this == &rhs)
			return *this;
		d_data.clear();
		d_rows = rhs.rows();
		d_cols = rhs.cols();
		d_data.resize(rhs.rows());
		for(int i = 0; i < rhs.rows(); ++i)
			for(int j = 0; j < rhs.cols(); ++j)
				d_data[i].push_back(rhs[i][j]);
		return *this;
	}

	std::vector<ValueType>& Matrix::operator[](int row)
	{
		if(row < 0 || row > d_rows)
			throw std::range_error("index out of bound");
		else 
			return d_data[row];
	}

	//std::vector<ValueType> Matrix::operator[](int row) const
	/**
	{
		std::vector<ValueType> b;
		if(row < 0 || row > d_rows)
			throw std::invalid_argument("index out of bound");
		else 
		{
			b = d_data[row];
			return b;
		}
	}
	**/

	const std::vector<ValueType>& Matrix::operator[](int row) const
	{
		if(row < 0 || row > d_rows)
			throw std::invalid_argument("index out of bound");
		else 
			return d_data[row];
	}

	/**
	std::vector<ValueType> Matrix::operator[](int row) const
	{
		if (row < 0 || row > d_rows)
			throw std::invalid_argument("index out of bound");
		else
			return d_data[row];
	}
	**/

	Matrix Matrix::operator+(const Matrix& b) const
	{
		if(d_rows != b.rows() && d_cols != b.cols())
			throw std::invalid_argument("Matrix a+b: Matrix b should have the same size as Matrix a"); 
		Matrix c(d_rows, d_cols);
		for(int i = 0; i < d_rows; ++i)b[i][j] = 4;
			for(int j = 0; j < d_cols; ++j)
				c[i][j] = d_data[i][j] + b[i][j]; //std::vector<ValueType> vbi = b[i]; vbi[j] = 4; 
		return c;
	}

	Matrix Matrix::operator-(const Matrix& b) const
	{
		if(d_rows != b.rows() && d_cols != b.cols())
			throw std::invalid_argument("Matrix a-b: Matrix b should have the same size as Matrix a"); 
		Matrix c(d_rows, d_cols);
		for(int i = 0; i < d_rows; ++i)
			for(int j = 0; j < d_cols; ++j)
				c[i][j] = d_data[i][j] - b[i][j];
		return c;
	}
	Matrix Matrix::operator*(const Matrix& b) const
	{
		if(d_cols != b.rows())
			throw std::invalid_argument("Matrix a*b: cols of Matrix a should equal to rows of Matrix b"); 
		Matrix c(d_rows, b.cols());
		for(int i = 0; i < d_rows; ++i)
		{ 
			for(int j = 0; j < b.cols(); ++j)
			{
				c[i][j] = 0;
				for(int k = 0; k < b.rows(); ++k)
				{
					c[i][j] += d_data[i][k] * b[k][j];
				}
			}
		}
		return c;
	}

	Matrix Matrix::diag(ValueType * data, int length)
	{
		//all zero matrix
		Matrix A(length, length);
        for(int i = 0; i < length; ++i)
			A[i][i] = data[i];
		return A;
	}

	Matrix Matrix::ones(int row, int column)
	{
		Matrix A(row, column);
		for(int i = 0; i < row; ++i)
			for(int j = 0; j < column; ++j)
				A[i][j] = 1;
		return A;
	}
	Matrix Matrix::indentity(int length)
	{
		if(length < 0)
			throw std::invalid_argument("Matrix rows and columns should be positive");
		Matrix A(length, length);
        for(int i = 0; i < length; ++i)
			for(int j = 0; j < length; ++j)
				A[i][i] = 1.0;
		return A;
	}
	
	void Matrix::print() const
	{
		std::cout << std::endl;
		for(int i = 0; i < d_rows; ++i)
		{
			for(int j = 0; j < d_cols; ++j)
			{
				std::cout << std::setw (8) << d_data[i][j] << ",";
			}
			std::cout << std::endl;
		}
	}
}//end namespace NMethod
