#include "matrix.h"

using namespace NMethod;
int main(int argc, char* argv[])
{
	Matrix a(2,2);
	ValueType data[] = {1,2,3,4};
	Matrix b(data,2,2);
	std::cout << "create matrix a with element zero " << std::endl;
	a.print();
	std::cout << "create matrix b with element 1 2 3 4 " << std::endl;
	b.print();
	ValueType data2[] = {1,1,1,1};
	Matrix c = Matrix::diag(data2, sizeof(data2)/sizeof(data2[0]));
	std::cout << "create diagonal matrix c " << std::endl;
	c.print();
	Matrix d = Matrix::ones(3,1);
	std::cout << "create a 3 x 1 matrix with all element 1 " << std::endl;
	d.print();
	Matrix e = Matrix::indentity(3);
	std::cout << "create identity matrix e " << std::endl;
	e.print();
	ValueType data3[] = {2,-1,-2,-4, 6, 3,-4,-2,8};
	Matrix f(data3, 3, 3);
	std::cout << "matrix f = " << std::endl;
	f.print();

	ValueType data4[] = {1,2,3,-2,5,6,2,3,5};
	Matrix g(data4, 3, 3);
    Matrix q(3,3);
	std::cout << "matrix g = " << std::endl;
    g.print();
	q = f + g;
	std::cout << "matrix f + g =  " << std::endl;
	q.print();
	q = f * g;
	std::cout << "matrix f*g = " << std::endl;
	q.print();
	system ("pause");
}