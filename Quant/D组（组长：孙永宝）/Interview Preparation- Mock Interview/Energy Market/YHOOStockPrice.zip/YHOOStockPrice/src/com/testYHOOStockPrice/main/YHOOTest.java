package com.testYHOOStockPrice.main;

import static org.junit.Assert.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import org.junit.Test;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.histquotes.Interval;

public class YHOOTest {
	@Test
	public void testYHOO() throws IOException {
		Calendar from = Calendar.getInstance();
		Calendar to = Calendar.getInstance();
		from.add(Calendar.YEAR, -2); // from 5 years ago
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Stock google = YahooFinance.get("GOOG", from, to, Interval.DAILY);
		
		for(HistoricalQuote quote:google.getHistory()){
			System.out.println(df.format(quote.getDate().getTime()) + " price:" + quote.getClose());
		}
	}
	
}
